public class Process {
    public  String name;
    public  int size;
    public boolean isAllocated=false;

    public Process(String name, int size) {
        this.name = name;
        this.size = size;
    }

}